
#include "Comparable.hpp"


void sort(Comparable** list, int N);
