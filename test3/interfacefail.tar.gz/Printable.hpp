#ifndef PRINTABLE_HPP__
#define PRINTABLE_HPP__

class Printable
{
public:
	virtual void print() = 0;
};

#endif
