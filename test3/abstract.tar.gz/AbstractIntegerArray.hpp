

class AbstractIntegerArray
{
private:
	int array_size;
	int* array;
	mutable int num_accesses;

protected:
	int get(int i) const;
	void set(int i, int value);


public:
	AbstractIntegerArray(int N);
	virtual ~AbstractIntegerArray();

	virtual int size() const;

	virtual int peek() const = 0;
	virtual void pop() = 0;
	virtual void push(int i) = 0;

	int getNumAccesses() const;

};


