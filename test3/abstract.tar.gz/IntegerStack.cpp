

#include "IntegerStack.hpp"




IntegerStack::IntegerStack(int N) : AbstractIntegerArray(N)
{
	this->top = 0; //# of things in the stack
}

IntegerStack::~IntegerStack()
{

}

int IntegerStack::size() const
{
	return this->top;
}	

int IntegerStack::peek() const
{
	if ( this->top <= 0 )
	{
		return -1;
	}

	return this->get(this->top - 1);
}

void IntegerStack::push(int i)
{
	this->set(this->top, i);
	this->top = this->top + 1;
}

void IntegerStack::pop()
{
	if ( this->top <= 0 )
	{
		return;
	}

	this->top = this->top - 1;
}









