
#include "AbstractIntegerArray.hpp"


class IntegerStack : public AbstractIntegerArray
{
private:
	int top;

public:
	IntegerStack(int N);
	virtual ~IntegerStack();

	virtual int size() const;

	virtual int peek() const;
	virtual void push(int i);
	virtual void pop();

};





