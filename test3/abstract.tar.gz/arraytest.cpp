

#include <stdio.h>
#include "IntegerStack.hpp"

void peekAndPrint(const AbstractIntegerArray* aia)
{
	printf("%d\n", aia->peek());
}

int main(int argc, char** argv)
{
	int N = 100;

	AbstractIntegerArray* aia = new IntegerStack(N);

	aia->push(100);
	aia->push(1000);
	aia->pop();
	aia->push(2000);
	aia->push(3);

	while ( aia->size() > 0 )
	{
		peekAndPrint(aia);
		aia->pop();
	}

	printf("%d accesses.\n", aia->getNumAccesses());

	return 0;
}
