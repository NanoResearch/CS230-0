#include "AbstractIntegerArray.hpp"
#include <stdlib.h>

int AbstractIntegerArray::get(int i) const
{
	this->num_accesses = this->num_accesses + 1;

	return this->array[i];
}

void AbstractIntegerArray::set(int i, int value)
{
	if ( i >= this->array_size )
	{
		this->array_size = i + 100;
		this->array = (int*)realloc(this->array, this->array_size * sizeof(int));
	}

	this->array[i] = value;
}


AbstractIntegerArray::AbstractIntegerArray(int N)
{
	this->array_size = N;
	this->array = (int*)malloc( N * sizeof(int));
	this->num_accesses = 0;
}

AbstractIntegerArray::~AbstractIntegerArray()
{
	free(this->array);
	this->array = 0;
}

int AbstractIntegerArray::size() const
{
	return this->array_size;
}


int AbstractIntegerArray::getNumAccesses() const
{
	return this->num_accesses;
}
		


		

