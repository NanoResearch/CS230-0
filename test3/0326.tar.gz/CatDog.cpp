
#include "CatDog.hpp"


CatDog::CatDog(const char* name) : Cat(name), Dog(name)
{
	
}

CatDog::~CatDog()
{

}



