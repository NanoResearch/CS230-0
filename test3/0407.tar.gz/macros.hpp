


#define CHECK_AND_FREE(A)  \
	if ( A != 0 ) \
	{ \
		free(A);\
		A = 0;\
	}

#define CHECK_DELETE_AND_FREE(A, length ) \
	if ( A != 0 )\
	{\
		for ( int i = 0; i < length; i++ )\
		{\
			if ( A[i] != 0 ) \
			{\
				delete A[i];\
			}\
		}\
		delete[] A;\
		A = 0;\
	}

	



