#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sort.hpp"

int main(void)
{
	size_t buflen = 1000;
	char* buffer = (char*)malloc(buflen);

	getline(&buffer, &buflen, stdin);

	printf("Original:%s\n", buffer);


	sort<char>(buffer, strlen(buffer)-1);

	printf("Sorted:%s\n", buffer);

	free(buffer);
	return 0;
}



