#include <stdlib.h>

template <class T>
int compare(T& c1, T& c2)
{
	if ( c1 > c2 )
	{
		return 1;
	}
	if ( c2 > c1 )
	{
		return -1;
	}

	return 0;
}

template <>
int compare<int>(int& c1, int& c2)
{
	return c1 - c2;
}	

template <class T>
void testAndSwap(T& a, T& b)
{
	if ( compare<T>(a,b) > 0 )
	{
		T t = a;
		a = b;
		b = t;
	}
}

template <class T>
void sort(T* data, int length)
{
	for ( int i = 0; i < length; i++ )
	{
		for ( int j = i+1; j < length; j++ )
		{
			testAndSwap(data[i], data[j]);
		}
	}
}


template <>
void sort<char>(char* data, int length)
{
	char* temp = (char*)malloc(length);

	int max = 0;
	for ( int i = 0; i < length; i++ )
	{
		if ( data[i] > max) 
		{
			max = data[i];
		}
	}

	int bit = 1;
	
	while ( bit < max )
	{
		int num_zeroes = 0;

		for ( int i = 0; i < length; i++ )
		{
			if ( (data[i] & bit) == 0 )
			{
				num_zeroes++;
			}
		}

		int cur_zero = num_zeroes - 1;
		int cur_one = length - 1;

		for ( int i = length - 1; i>= 0; i-- )
		{
			if ( (data[i] & bit) == 0 )
			{
				temp[ cur_zero ] = data[i];
				cur_zero--;
			}
			else
			{
				temp[ cur_one ] = data[i];
				cur_one--;
			}	
		}

		for ( int i = 0; i < length; i++ )
		{
			data[i] = temp[i];
		}

		bit <<= 1;
	}



	free(temp); temp = 0;
}























