#include "macros.hpp"

#include <stdlib.h>

class Bogus
{
public:
	Bogus(){}
	~Bogus(){}
int i;
};


int main(void)
{
	int l = 100;
	Bogus** b = (Bogus**)malloc(l * sizeof(Bogus*));
	for ( int i = 0; i < l; i++ )
	{
		b[i] = new Bogus();
	}

	CHECK_DELETE_AND_FREE(b, l);

	return 0;
}






