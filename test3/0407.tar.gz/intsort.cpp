#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sort.hpp"

int main(void)
{
	int buflen = 1000;
	int* buffer = (int*)malloc(buflen*sizeof(int));

	int count = 0;

	printf("Enter a list of numbers, ended with a negative number:\n");

	while ( count < buflen )
	{
		scanf("%d", &(buffer[count]));

		if ( buffer[count] < 0 )
		{
			break;
		}

		count++;
	}

	sort<int>(buffer, count);

	printf("Sorted:");

	for ( int i = 0; i < count; i++ )
	{
		printf("%d ", buffer[i]);
	}
	printf("\n");


	free(buffer); buffer = 0;
	

	return 0;
}
