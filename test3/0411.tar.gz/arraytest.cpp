
#include "Array.hpp"

#include <stdio.h>


int main(void)
{
	int N = 100;

	Array* a = new Array(N);

	try
	{
		a->get(-1);
	}
	catch ( OutOfBounds o )
	{
		printf("%s\n", o.what() );
	}
	catch ( std::exception e )
	{
		printf("%s\n", e.what());
	}
	return 0;
}
