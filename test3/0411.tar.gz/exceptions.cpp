#include <iostream>
#include "stdio.h"

int main(void)
{
	printf("Enter a number:\n");
	try
	{
		// DO SOMETHING!
		int i;

		std::cin >> i;

		// something may be thrown!
		//
		throw 5;
		//
	}
	catch ( int error_code )
	{
		printf("Error: %d\n", error_code);
	}
	catch ( char* error_msg )
	{
		
		throw;
	}
	catch ( std::exception e )
	{
		printf("%s\n", e.what() );
	}
	catch (...)
	{
		printf("Unknown exception type!\n");
		throw;
	}

	return 0;
}
