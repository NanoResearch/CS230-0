






int gobal_error_code = 0;


typedef struct img_struct img;

#define NO_ERROR 0
#define ERROR_NO_FILE 1 
#define ERROR_WRONG_SIZE 2
int loadImage(img* i, FILE* f);



img* getImage(FILE* f);



imt* getImage(char* filename);

