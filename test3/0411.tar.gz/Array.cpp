
#include "Array.hpp"
#include <stdlib.h>

OutOfBounds::OutOfBounds(const OutOfBounds& a)
{
	this->msg = a.msg;
}

OutOfBounds::OutOfBounds(const char* msg)
{
	this->msg = msg;
}

//OutOfBounds::~OutOfBounds()
//{
//	this->msg = 0;
//}

char* OutOfBounds::what()
{
	return (char*)this->msg;
}



 Array::Array(int length)
 {
	this->length = length;
	this->data = (int*)malloc(length * sizeof(int));
 }

 Array::~Array()
 {
	free(this->data);
	this->data = 0;

}

int Array::get(int i)//  throw(OutOfBounds)
{
	if ( i < 0 || i >= this->length )
	{
		throw OutOfBounds("Out of bounds!");
	}

	return this->data[i];
}

void Array::set(int i, int value)  // throw(OutOfBounds)
{
	if ( i < 0 || i>= this->length )
	{
		throw OutOfBounds("Out of Bounds!");
	}
	
	this->data[i] = value;
}







