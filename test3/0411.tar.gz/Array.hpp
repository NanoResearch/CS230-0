
#include <iostream>

class OutOfBounds : public std::exception
{
private:
	const char* msg;

public:
	OutOfBounds(const char* msg);
	OutOfBounds(const OutOfBounds& oob);
	//virtual ~OutOfBounds();


	virtual char* what();
};


class Array
{
private:
	int* data;
	int length;

public:
	Array(int length);
	virtual ~Array();
	
	int get(int i); // throw(OutOfBounds); // Alert the user of possible throwing
	void set(int i, int value); // throw(OutOfBounds);

};



