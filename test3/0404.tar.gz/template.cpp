
#include <stdio.h>
#include "Stack.hpp"


int main(void)
{
	AbstractArray<char>* aia = new Stack<char>(100);

	aia->push('H');
	aia->push('i');
	aia->push('!');
	aia->pop();
	aia->push('?');

	aia->print();
	
	delete aia;
	return 0;
}


