#include "AbstractArray.hpp"

//class IntegerStack : public AbstractArray<int>
//{
//
//};


// template <class Type1, class Type2, class Type3>
template <class Type>
class Stack : public AbstractArray<Type>
{
private:
	int top;

public:
	Stack(int N) : AbstractArray<Type>(N)
	{
		this->top = 0;
	}
	
	virtual ~Stack()
	{
	}

	virtual int size()
	{
		return this->top;
	}
	
	virtual Type peek()
	{
		return this->get(this->top - 1);
	}

	virtual void push(Type value)
	{		
		this->set(this->top, value);
		(this->top)++;
	}

	virtual void pop()
	{	
		if ( this->top > 0 )
		{
			(this->top)--;
		}
	}
};


