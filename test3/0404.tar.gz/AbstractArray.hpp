#include <stdlib.h>

// template <typename Type>
template <class Type>
class AbstractArray
{
private:
	int array_size;
	Type* array;

protected:
	Type get(int i) 
	{
		if ( i < 0 || i >= this->size() )
		{
			// Q: what happens if this cannot cast to Type?
			return 0;
		}
		return this->array[i];
	}


	void set(int i, Type value)
	{
		if ( i >= this->array_size )
		{
			this->array_size = i + 100;
this->array = (Type*)realloc(this->array, this->array_size * sizeof(Type));
		}

		this->array[i] = value;
	}

public:
	AbstractArray(int N)
	{
		this->array_size = N;
		this->array = (Type*) malloc(this->array_size * sizeof(Type));
	}

	virtual ~AbstractArray()
	{
		free(this->array);
		this->array = 0;
	}

	virtual int size()
	{
		return this->array_size;
	}
	
	virtual Type peek() = 0;
	virtual void push(Type value) = 0;
	virtual void pop() = 0;
};


template <>
class AbstractArray<char>
{
private:
	int array_size;
	char* array;

protected:
	char get(int i )
	{
		return this->array[i];
	}

	void set(int i, char c)
	{
		this->array[i] = c;
	}

public:
	AbstractArray(int N)
	{
		this->array_size = N;
		this->array = (char*)malloc(N);
	}
	
	virtual ~AbstractArray()
	{
		free(this->array);
		this->array = 0;
	}

	virtual int size()
	{
		return this->array_size;
	}

	virtual char peek() = 0;
	virtual void push(char c) = 0;
	virtual void pop() = 0;


	void print()
	{
		for ( int i = 0; i < this->size(); i++ )
		{
			printf("%c", this->get(i));
		}
		printf("\n");
	}

};

















