#include <stdio.h>
#include <stack>


int main(int argc, char** argv)
{
	std::stack<char>* s = new std::stack<char>();

	char c;

	while (  ( c=getc(stdin) ) != EOF )
	{	
		if ( c == '{' || c == '[' || c == '(' )
		{
			s->push(c);
		}
		else if ( c == '}' || c == ']' || c == ')' )
		{
			if ( s->size() == 0 )
			{
				printf("Not properly nested (1)!\n");
				return 0;
			}

			char d = s->top();
			
			bool result = true;
			if ( c == '}' && d != '{' )
			{
				result = false;
			}
			if ( c == ')' && d != '(' )
			{
				result = false;
			}
			if ( c == ']' && d != '[' )
			{
				result = false;
			}

			if ( !result )
			{
				printf("Not properly nested (2)!\n");
				return 0;
			}

			s->pop();
		}
	}

	if ( s->size() > 0 )
	{		
		printf("Not properly nested (3)!\n");
		return 0;
	}

	printf("Properly nested!\n");

	delete s; // TODO: do this everywhere!

	return 0;
}




