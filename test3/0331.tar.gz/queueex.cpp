#include <stdio.h>

#include <queue>
#include <utility>


int main(int argc, char** argv)
{	
	std::queue< std::pair< int,int > >* q = 
			new std::queue< std::pair<int,int> >();

	int x, y;
	x = 0;
	y = 10;
	std::pair<int,int> p(x,y);

	q->push( p );

	while ( q->size() > 0 )
	{
		std::pair<int, int> u = q->front();
		q->pop();

		/* local search over u's neighbors! */
	}

	
	delete q;

	return 0;
}
